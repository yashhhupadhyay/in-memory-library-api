package com.example.library;

import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/books")
public class BookController {

    private Map<Integer, Book> bookStore = new HashMap<>();

    @PostMapping
    public String addBook(@RequestBody Book book) {
        bookStore.put(book.getId(), book);
        return "Book added successfully";
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable int id) {
        return bookStore.get(id);
    }

    @GetMapping("/search")
    public List<Book> getBooksByYear(@RequestParam int year) {
        return bookStore.values()
                .stream()
                .filter(book -> book.getYear() == year)
                .collect(Collectors.toList());
    }

    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable int id) {
        bookStore.remove(id);
        return "Book deleted successfully";
    }
}
