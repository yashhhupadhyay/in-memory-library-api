# 📚 In-Memory Library API

## 1. Project Title & Goal
A Spring Boot REST API that manages a library book inventory using strictly in-memory storage.

## 2. Setup Instructions
```bash
mvn clean install
mvn spring-boot:run
```
Base URL: http://localhost:8080
Future Improvements (If I had 2 more days)
Add global exception handling using @ControllerAdvice
Implement DTOs & validation (@NotNull, @Min, etc.)
Add Swagger UI documentation
Write unit tests using JUnit & Mockito
Extend search filters (author, title)